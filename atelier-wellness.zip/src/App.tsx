import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X, Image as ImageIcon, Music, Brain, Sparkles, Send, Download, Loader2, Plus, ArrowRight } from 'lucide-react';
import { useLocation } from 'react-router-dom';
import { cn } from '@/src/lib/utils';
import { generateHighThinkingResponse, generateImage, editImage, generateMusic } from './services/geminiService';
import Markdown from 'react-markdown';
import PillNav from './components/PillNav';

// --- Components ---

const Hero = ({ onBook }: { onBook: () => void }) => {
  return (
    <section id="home" className="relative h-screen flex items-center justify-center overflow-hidden px-6">
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&q=80&w=2000" 
          alt="Wellness Ritual Sanctuary" 
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-black/5"></div>
        <div className="absolute inset-0 bg-gradient-to-b from-atelier-bg/30 via-transparent to-atelier-bg/95"></div>
      </div>
      
      <div className="relative z-10 text-center max-w-5xl">
        <motion.span 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-[10px] md:text-xs font-medium tracking-[0.6em] uppercase text-atelier-text/60 mb-10 block"
        >
          Artistry in Motion
        </motion.span>
        <motion.h1 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.4 }}
          className="text-5xl md:text-[110px] font-serif mb-12 leading-[0.95] tracking-tight text-atelier-text"
        >
          The Architecture <br /> of Well-being
        </motion.h1>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.8 }}
          className="flex flex-col md:flex-row items-center justify-center gap-12 mt-4"
        >
          <button 
            onClick={onBook}
            className="bg-atelier-cta text-white px-12 py-5 text-xs font-medium tracking-[0.2em] uppercase hover:bg-atelier-accent transition-all duration-500 shadow-sm"
          >
            Explore Rituals
          </button>
          <a href="#classes" className="text-xs font-medium tracking-[0.2em] uppercase border-b border-atelier-text/20 pb-1 hover:border-atelier-text transition-all text-atelier-text/80 hover:text-atelier-text">
            View Disciplines
          </a>
        </motion.div>
      </div>

      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 1 }}
        className="absolute bottom-12 left-1/2 -translate-x-1/2 flex flex-col items-center gap-4"
      >
        <span className="text-[10px] uppercase tracking-[0.5em] text-atelier-text/40">Scroll to Explore</span>
        <div className="w-px h-20 bg-atelier-text/10"></div>
      </motion.div>
    </section>
  );
};

const FeaturedIn = () => {
  const logos = ['VOGUE', 'TimeOut', 'ELLE', 'BAZAAR', 'Wallpaper*', 'AD'];
  return (
    <div className="py-20 bg-atelier-bg border-y border-atelier-accent/10 overflow-hidden">
      <div className="flex animate-marquee whitespace-nowrap">
        {[...logos, ...logos].map((logo, i) => (
          <span key={i} className="mx-12 text-3xl md:text-4xl font-serif opacity-30 grayscale hover:opacity-100 transition-opacity cursor-default">
            {logo}
          </span>
        ))}
      </div>
    </div>
  );
};

const ServiceCard = ({ title, description, image }: { title: string, description: string, image: string }) => (
  <motion.div 
    whileHover={{ y: -10 }}
    className="group cursor-pointer"
  >
    <div className="aspect-[3/4] overflow-hidden mb-6 bg-atelier-accent/10">
      <img 
        src={image} 
        alt={title} 
        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
        referrerPolicy="no-referrer"
      />
    </div>
    <h3 className="text-2xl font-serif mb-2">{title}</h3>
    <p className="text-sm text-atelier-text/60 leading-relaxed">{description}</p>
  </motion.div>
);

const Services = () => {
  const services = [
    {
      title: "Sculpt & Flow",
      description: "A dynamic fusion of pilates and yoga designed to lengthen and strengthen your core.",
      image: "https://images.unsplash.com/photo-1518611012118-29617b0ccd0a?auto=format&fit=crop&q=80&w=800"
    },
    {
      title: "Breathwork Ritual",
      description: "Immersive guided meditation and pranayama to restore balance to your nervous system.",
      image: "https://images.unsplash.com/photo-1506126613408-eca07ce68773?auto=format&fit=crop&q=80&w=800"
    },
    {
      title: "Artistic Movement",
      description: "Contemporary dance-inspired sequences that celebrate the expressive power of the body.",
      image: "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?auto=format&fit=crop&q=80&w=800"
    }
  ];

  return (
    <section id="classes" className="py-32 px-6 max-w-7xl mx-auto">
      <div className="text-center mb-20">
        <h2 className="text-4xl md:text-5xl font-serif mb-4">Our Disciplines</h2>
        <div className="w-20 h-px bg-atelier-accent mx-auto"></div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
        {services.map((s, i) => <ServiceCard key={i} {...s} />)}
      </div>
    </section>
  );
};

const AIStudio = () => {
  const [activeTab, setActiveTab] = useState<'thinking' | 'image' | 'music'>('thinking');
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [imageSize, setImageSize] = useState<'1K' | '2K' | '4K'>('1K');
  const [isFullLength, setIsFullLength] = useState(false);
  const [baseImage, setBaseImage] = useState<string | null>(null);
  const [hasApiKey, setHasApiKey] = useState(false);

  useEffect(() => {
    const checkApiKey = async () => {
      const aistudio = (window as any).aistudio;
      if (aistudio?.hasSelectedApiKey) {
        const hasKey = await aistudio.hasSelectedApiKey();
        setHasApiKey(hasKey);
      }
    };
    checkApiKey();
  }, []);

  const handleSelectKey = async () => {
    const aistudio = (window as any).aistudio;
    if (aistudio?.openSelectKey) {
      await aistudio.openSelectKey();
      setHasApiKey(true);
    }
  };

  const handleAction = async () => {
    if (!prompt) return;
    if (!hasApiKey && (activeTab === 'image' || activeTab === 'music')) {
      await handleSelectKey();
    }
    setLoading(true);
    setResult(null);
    try {
      if (activeTab === 'thinking') {
        const res = await generateHighThinkingResponse(prompt);
        setResult(res);
      } else if (activeTab === 'image') {
        if (baseImage) {
          const res = await editImage(prompt, baseImage.split(',')[1], 'image/png');
          setResult(res);
        } else {
          const res = await generateImage(prompt, imageSize);
          setResult(res);
        }
      } else if (activeTab === 'music') {
        const res = await generateMusic(prompt, isFullLength);
        setResult(res);
      }
    } catch (e) {
      console.error(e);
      setResult("An error occurred while generating. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setBaseImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <section className="py-32 px-6 bg-atelier-bg border-t border-atelier-accent/10">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16">
          <span className="text-xs font-medium tracking-[0.3em] uppercase text-atelier-accent mb-4 block">AI Wellness Concierge</span>
          <h2 className="text-4xl md:text-5xl font-serif">Curate Your Experience</h2>
        </div>

        <div className="bg-white p-8 md:p-12 shadow-sm border border-atelier-accent/10">
          <div className="flex flex-wrap gap-4 mb-10 border-b border-atelier-accent/10 pb-6">
            <button 
              onClick={() => setActiveTab('thinking')}
              className={cn("flex items-center gap-2 px-4 py-2 text-sm font-medium transition-all", activeTab === 'thinking' ? "text-atelier-cta border-b-2 border-atelier-cta" : "text-atelier-accent hover:text-atelier-text")}
            >
              <Brain size={18} /> High Thinking
            </button>
            <button 
              onClick={() => setActiveTab('image')}
              className={cn("flex items-center gap-2 px-4 py-2 text-sm font-medium transition-all", activeTab === 'image' ? "text-atelier-cta border-b-2 border-atelier-cta" : "text-atelier-accent hover:text-atelier-text")}
            >
              <ImageIcon size={18} /> Visual Studio
            </button>
            <button 
              onClick={() => setActiveTab('music')}
              className={cn("flex items-center gap-2 px-4 py-2 text-sm font-medium transition-all", activeTab === 'music' ? "text-atelier-cta border-b-2 border-atelier-cta" : "text-atelier-accent hover:text-atelier-text")}
            >
              <Music size={18} /> Sonic Rituals
            </button>
          </div>

          <div className="space-y-6">
            {activeTab === 'image' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium uppercase tracking-widest text-atelier-accent">Base Image (Optional for Editing)</span>
                  {baseImage && (
                    <button onClick={() => setBaseImage(null)} className="text-[10px] uppercase tracking-widest text-red-500 hover:text-red-700">Clear</button>
                  )}
                </div>
                <div className="flex gap-4 items-center">
                  <label className="cursor-pointer flex items-center gap-2 px-4 py-2 border border-atelier-accent/30 text-[10px] uppercase tracking-widest hover:border-atelier-accent transition-all">
                    <Plus size={14} /> {baseImage ? "Change Image" : "Upload Image"}
                    <input type="file" className="hidden" accept="image/*" onChange={handleImageUpload} />
                  </label>
                  {baseImage && (
                    <div className="w-12 h-12 border border-atelier-accent/20 overflow-hidden">
                      <img src={baseImage} alt="Base" className="w-full h-full object-cover" />
                    </div>
                  )}
                </div>
              </div>
            )}

            <div>
              <label className="text-xs font-medium uppercase tracking-widest text-atelier-accent mb-2 block">
                {activeTab === 'thinking' ? "Ask our wellness expert" : activeTab === 'image' ? (baseImage ? "Describe the edit" : "Describe your vision") : "Describe your soundscape"}
              </label>
              <div className="relative">
                <textarea 
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder={activeTab === 'thinking' ? "How can I integrate mindfulness into a busy corporate schedule?" : activeTab === 'image' ? (baseImage ? "Add a soft golden glow and some floating petals..." : "A minimalist zen garden with floating stone steps and soft morning light...") : "A 30-second cinematic orchestral track with soft piano and ethereal pads..."}
                  className="w-full bg-atelier-bg border border-atelier-accent/20 p-4 text-atelier-text focus:outline-none focus:border-atelier-accent transition-colors min-h-[120px] resize-none"
                />
              </div>
            </div>

            {activeTab === 'image' && (
              <div className="flex items-center gap-6">
                <span className="text-xs font-medium uppercase tracking-widest text-atelier-accent">Resolution:</span>
                <div className="flex gap-4">
                  {(['1K', '2K', '4K'] as const).map(size => (
                    <button 
                      key={size}
                      onClick={() => setImageSize(size)}
                      className={cn("text-xs px-3 py-1 border transition-all", imageSize === size ? "bg-atelier-cta text-white border-atelier-cta" : "border-atelier-accent/30 hover:border-atelier-accent")}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'music' && (
              <div className="flex items-center gap-4">
                <button 
                  onClick={() => setIsFullLength(!isFullLength)}
                  className={cn("flex items-center gap-2 text-xs font-medium uppercase tracking-widest px-4 py-2 border transition-all", isFullLength ? "bg-atelier-cta text-white border-atelier-cta" : "border-atelier-accent/30 hover:border-atelier-accent")}
                >
                  {isFullLength ? "Full Length Track" : "Short Clip (30s)"}
                </button>
              </div>
            )}

            <button 
              onClick={handleAction}
              disabled={loading || !prompt}
              className="w-full bg-atelier-cta text-white py-4 text-sm font-medium tracking-widest uppercase flex items-center justify-center gap-2 hover:bg-atelier-accent transition-all disabled:opacity-50"
            >
              {loading ? <Loader2 className="animate-spin" size={18} /> : <Sparkles size={18} />}
              {loading ? "Generating..." : (!hasApiKey && (activeTab === 'image' || activeTab === 'music')) ? "Select API Key to Generate" : "Curate Experience"}
            </button>

            <AnimatePresence mode="wait">
              {result && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="mt-10 pt-10 border-t border-atelier-accent/10"
                >
                  {activeTab === 'thinking' ? (
                    <div className="markdown-body prose prose-slate max-w-none">
                      <Markdown>{result}</Markdown>
                    </div>
                  ) : activeTab === 'image' ? (
                    <div className="space-y-4">
                      <img src={result} alt="Generated" className="w-full aspect-square object-cover shadow-lg" />
                      <a href={result} download="atelier-vision.png" className="inline-flex items-center gap-2 text-xs font-medium uppercase tracking-widest hover:text-atelier-accent transition-colors">
                        <Download size={14} /> Download Vision
                      </a>
                    </div>
                  ) : (
                    <div className="bg-atelier-bg p-6 border border-atelier-accent/10">
                      <audio controls src={result} className="w-full" />
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="bg-atelier-bg py-24 px-6 border-t border-atelier-accent/10">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12">
        <div className="col-span-1 md:col-span-1">
          <div className="text-2xl font-serif tracking-tight font-semibold mb-6">ATELIER</div>
          <p className="text-sm text-atelier-text/50 leading-relaxed">
            A sanctuary for the modern soul. Artistry in motion, mindfulness in spirit.
          </p>
        </div>
        
        <div>
          <h4 className="text-xs font-medium uppercase tracking-[0.3em] text-atelier-accent mb-6">Navigation</h4>
          <ul className="space-y-4">
            {['Home', 'About', 'Classes', 'Book', 'Shop'].map(item => (
              <li key={item}><a href="#" className="text-sm hover:text-atelier-accent transition-colors">{item}</a></li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="text-xs font-medium uppercase tracking-[0.3em] text-atelier-accent mb-6">Connect</h4>
          <ul className="space-y-4">
            {['Instagram', 'WhatsApp', 'LinkedIn', 'Spotify'].map(item => (
              <li key={item}><a href="#" className="text-sm hover:text-atelier-accent transition-colors">{item}</a></li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="text-xs font-medium uppercase tracking-[0.3em] text-atelier-accent mb-6">Newsletter</h4>
          <div className="relative">
            <input 
              type="email" 
              placeholder="Your Email" 
              className="w-full bg-transparent border-b border-atelier-accent/30 py-2 text-sm focus:outline-none focus:border-atelier-text transition-colors"
            />
            <button className="absolute right-0 bottom-2 text-atelier-accent hover:text-atelier-text transition-colors">
              <ArrowRight size={18} />
            </button>
          </div>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto mt-24 pt-8 border-t border-atelier-accent/10 flex flex-col md:flex-row justify-between items-center gap-4">
        <p className="text-[10px] uppercase tracking-widest text-atelier-accent">© 2026 Atelier Wellness Studio. All Rights Reserved.</p>
        <div className="flex gap-8">
          <a href="#" className="text-[10px] uppercase tracking-widest text-atelier-accent hover:text-atelier-text">Privacy Policy</a>
          <a href="#" className="text-[10px] uppercase tracking-widest text-atelier-accent hover:text-atelier-text">Terms of Service</a>
        </div>
      </div>
    </footer>
  );
};

const Shop = () => {
  const products = [
    {
      name: "Ceremonial Matcha Kit",
      price: "$120",
      image: "https://images.unsplash.com/photo-1582793988951-9aed5509eb97?auto=format&fit=crop&q=80&w=800"
    },
    {
      name: "Hand-Poured Alabaster Candle",
      price: "$85",
      image: "https://images.unsplash.com/photo-1603006905003-be475563bc59?auto=format&fit=crop&q=80&w=800"
    },
    {
      name: "Weighted Silk Eye Mask",
      price: "$45",
      image: "https://images.unsplash.com/photo-1616394584738-fc6e612e71b9?auto=format&fit=crop&q=80&w=800"
    }
  ];

  return (
    <section id="shop" className="py-32 px-6 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
          <div>
            <span className="text-xs font-medium tracking-[0.3em] uppercase text-atelier-accent mb-4 block">The Atelier Edit</span>
            <h2 className="text-4xl md:text-5xl font-serif">Curated Essentials</h2>
          </div>
          <a href="#" className="text-sm font-medium tracking-widest uppercase border-b border-atelier-accent/30 pb-1 hover:border-atelier-text transition-all">
            View All Products
          </a>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {products.map((product, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="group cursor-pointer"
            >
              <div className="aspect-square overflow-hidden mb-6 bg-atelier-bg">
                <img 
                  src={product.image} 
                  alt={product.name} 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
              </div>
              <h3 className="text-xl font-serif mb-1">{product.name}</h3>
              <p className="text-sm text-atelier-accent">{product.price}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Contact = () => {
  return (
    <section id="contact" className="py-32 px-6 bg-atelier-bg">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-24">
        <div>
          <span className="text-xs font-medium tracking-[0.3em] uppercase text-atelier-accent mb-4 block">Get in Touch</span>
          <h2 className="text-4xl md:text-6xl font-serif mb-8">Visit the Sanctuary</h2>
          <div className="space-y-8">
            <div>
              <h4 className="text-xs font-medium uppercase tracking-widest text-atelier-accent mb-2">Location</h4>
              <p className="text-lg font-serif">124 Artistry Lane, <br />Chelsea, New York 10011</p>
            </div>
            <div>
              <h4 className="text-xs font-medium uppercase tracking-widest text-atelier-accent mb-2">Hours</h4>
              <p className="text-sm">Mon — Fri: 06:00 - 21:00</p>
              <p className="text-sm">Sat — Sun: 08:00 - 18:00</p>
            </div>
            <div>
              <h4 className="text-xs font-medium uppercase tracking-widest text-atelier-accent mb-2">Inquiries</h4>
              <p className="text-sm">hello@atelierwellness.com</p>
              <p className="text-sm">+1 (212) 555-0198</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white p-8 md:p-12 shadow-sm border border-atelier-accent/10">
          <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="text-[10px] uppercase tracking-widest text-atelier-accent mb-2 block">First Name</label>
                <input type="text" className="w-full bg-atelier-bg border border-atelier-accent/10 p-3 text-sm focus:outline-none focus:border-atelier-accent transition-colors" />
              </div>
              <div>
                <label className="text-[10px] uppercase tracking-widest text-atelier-accent mb-2 block">Last Name</label>
                <input type="text" className="w-full bg-atelier-bg border border-atelier-accent/10 p-3 text-sm focus:outline-none focus:border-atelier-accent transition-colors" />
              </div>
            </div>
            <div>
              <label className="text-[10px] uppercase tracking-widest text-atelier-accent mb-2 block">Email Address</label>
              <input type="email" className="w-full bg-atelier-bg border border-atelier-accent/10 p-3 text-sm focus:outline-none focus:border-atelier-accent transition-colors" />
            </div>
            <div>
              <label className="text-[10px] uppercase tracking-widest text-atelier-accent mb-2 block">Message</label>
              <textarea className="w-full bg-atelier-bg border border-atelier-accent/10 p-3 text-sm focus:outline-none focus:border-atelier-accent transition-colors min-h-[120px] resize-none" />
            </div>
            <button className="w-full bg-atelier-cta text-white py-4 text-xs font-medium tracking-widest uppercase hover:bg-atelier-accent transition-all">
              Send Message
            </button>
          </form>
        </div>
      </div>
    </section>
  );
};

const BookingModal = ({ isOpen, onClose }: { isOpen: boolean, onClose: () => void }) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-atelier-text/40 backdrop-blur-sm"
          />
          <motion.div 
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative bg-atelier-bg w-full max-w-2xl p-8 md:p-16 shadow-2xl overflow-y-auto max-h-[90vh]"
          >
            <button onClick={onClose} className="absolute top-6 right-6 text-atelier-accent hover:text-atelier-text transition-colors">
              <X size={24} />
            </button>
            
            <div className="text-center mb-12">
              <span className="text-[10px] uppercase tracking-[0.4em] text-atelier-accent mb-4 block">Reservation</span>
              <h2 className="text-3xl md:text-5xl font-serif">Book Your Ritual</h2>
            </div>

            <div className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="text-[10px] uppercase tracking-widest text-atelier-accent mb-2 block">Select Discipline</label>
                  <select className="w-full bg-white border border-atelier-accent/20 p-3 text-sm focus:outline-none focus:border-atelier-accent appearance-none">
                    <option>Sculpt & Flow</option>
                    <option>Breathwork Ritual</option>
                    <option>Artistic Movement</option>
                    <option>Private Session</option>
                  </select>
                </div>
                <div>
                  <label className="text-[10px] uppercase tracking-widest text-atelier-accent mb-2 block">Date</label>
                  <input type="date" className="w-full bg-white border border-atelier-accent/20 p-3 text-sm focus:outline-none focus:border-atelier-accent" />
                </div>
              </div>
              
              <div>
                <label className="text-[10px] uppercase tracking-widest text-atelier-accent mb-2 block">Select Time</label>
                <div className="grid grid-cols-3 gap-3">
                  {['07:00', '09:30', '12:00', '16:30', '18:00', '19:30'].map(time => (
                    <button key={time} className="py-2 border border-atelier-accent/20 text-xs hover:border-atelier-cta hover:bg-atelier-cta hover:text-white transition-all">
                      {time}
                    </button>
                  ))}
                </div>
              </div>

              <button className="w-full bg-atelier-cta text-white py-5 text-sm font-medium tracking-widest uppercase hover:bg-atelier-accent transition-all">
                Confirm Reservation
              </button>
              
              <p className="text-[10px] text-center text-atelier-accent uppercase tracking-widest">
                Cancellation required 24 hours in advance.
              </p>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

// --- Main App ---

export default function App() {
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const location = useLocation();

  const navItems = [
    { label: 'Home', href: '#home' },
    { label: 'About', href: '#about' },
    { label: 'Classes', href: '#classes' },
    { label: 'Shop', href: '#shop' },
    { label: 'Contact', href: '#contact' },
    { label: 'Book', onClick: () => setIsBookingOpen(true) },
  ];

  return (
    <div className="min-h-screen selection:bg-atelier-accent selection:text-white">
      <div className="fixed top-6 left-1/2 -translate-x-1/2 z-[100] pointer-events-none w-full max-w-7xl px-4 md:px-6 flex justify-center">
        <div className="pointer-events-auto">
          <PillNav 
            logo="ATELIER"
            items={navItems}
            activeHref={location.hash || '#home'}
            baseColor="#f5f2ed"
            pillColor="#1a1a1a"
            pillTextColor="#f5f2ed"
            hoveredPillTextColor="#1a1a1a"
          />
        </div>
      </div>
      <main>
        <Hero onBook={() => setIsBookingOpen(true)} />
        <FeaturedIn />
        
        <section id="about" className="py-32 px-6 max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1 }}
          >
            <h2 className="text-4xl md:text-6xl font-serif mb-8 leading-tight">
              We believe wellness is the ultimate form of self-expression.
            </h2>
            <p className="text-lg text-atelier-text/60 font-sans max-w-2xl mx-auto leading-relaxed">
              Our studio is designed to be a canvas for your personal growth. Through curated movement, sound, and visual artistry, we help you sculpt a life of balance and beauty.
            </p>
          </motion.div>
        </section>

        <Services />
        <Shop />
        <AIStudio />
        <Contact />
        
        <section className="py-32 px-6 bg-atelier-cta text-white text-center">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-4xl md:text-6xl font-serif mb-10">Ready to begin?</h2>
            <button 
              onClick={() => setIsBookingOpen(true)}
              className="border border-white/30 px-12 py-5 text-sm font-medium tracking-widest uppercase hover:bg-white hover:text-atelier-cta transition-all duration-500"
            >
              Book Your First Ritual
            </button>
          </div>
        </section>
      </main>
      <Footer />
      <BookingModal isOpen={isBookingOpen} onClose={() => setIsBookingOpen(false)} />
    </div>
  );
}
